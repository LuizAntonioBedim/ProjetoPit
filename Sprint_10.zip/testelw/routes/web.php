<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EmailController;
use App\Http\Controllers\RespostaController;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dicas', function () {
    return view('dicas');
});


Route::get('/email', function () {
    return view('email');
});


Route::post('/respostas', [RespostaController::class, 'store'])->name('respostas.store');
Route::get('/respostas', [RespostaController::class, 'show'])->name('respostas.show');


Route::get('/contato', [EmailController::class, 'create'])->name('email.create');
Route::post('/contato', [EmailController::class, 'sendEmail'])->name('email.send');

Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified',
])->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');
});
