<p>Nome: <?php echo e($name); ?></p>
<p>Email: <?php echo e($email); ?></p>
<p>Mensagem: <?php echo e($message); ?></p><?php /**PATH C:\Users\igorc\Herd\testelw\resources\views/email_template.blade.php ENDPATH**/ ?>