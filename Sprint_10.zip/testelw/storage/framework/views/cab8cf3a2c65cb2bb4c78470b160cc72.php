<?php $__env->startSection('conteudo'); ?>



    <div id="telalanding">


        <div id="landingpg">
        Axotech é uma plataforma inovadora para personalização de PCs, projetada para simplificar
        o processo de escolha de hardware de acordo com as necessidades do cliente. Ao iniciar, o
        usuário define seu orçamento e preenche um formulário detalhado, onde são coletadas informações
         sobre suas preferências e requisitos específicos. Com base nessas respostas, o Axotech utiliza
         algoritmos avançados para recomendar uma configuração de PC otimizada em termos de desempenho e
         compatibilidade, garantindo uma experiência de usuário livre de complicações técnicas.
        <a href="/register"><button class="botaocad" id="btncad">AVANÇAR</button></a>
        </div>

    </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.landinglayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\igorc\Herd\testelw\resources\views/welcome.blade.php ENDPATH**/ ?>