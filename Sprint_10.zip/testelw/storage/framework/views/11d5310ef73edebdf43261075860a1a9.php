<?php echo e($slot); ?>

<?php /**PATH D:\BACKUPPITE\testelw\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>