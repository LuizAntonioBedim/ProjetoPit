<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\igorc\Herd\testelw\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>