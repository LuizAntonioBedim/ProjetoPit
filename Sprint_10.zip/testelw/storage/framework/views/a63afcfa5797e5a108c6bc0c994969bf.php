<?php echo e($slot); ?>

<?php /**PATH C:\Users\rodri\Herd\pits-\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>