<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH H:\testelw\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>