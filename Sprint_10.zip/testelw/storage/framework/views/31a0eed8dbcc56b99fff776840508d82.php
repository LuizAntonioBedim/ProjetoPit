<?php echo e($slot); ?>

<?php /**PATH H:\testelw\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>