<?php echo e($slot); ?>

<?php /**PATH D:\BACKUPPITE\testelw\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>