<!DOCTYPE html>
<html lang="pt-br">


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content=" initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
        integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <title>AxoTech</title>
</head>
<style>
    * {
        box-sizing: border-box;
        margin: 0 auto;
    }

    .bg {
        background-image: "fundo.png";
        background-attachment: fixed;
        background-blend-mode: multiply;
        background-color: rgba(0%, 0%, 0%, 70%);
    }

    #cabecalho {
        background-color: #180236;
        color: white;
        padding: 1%;
        display: flex;
        gap: 90vh;
    }

    .titulo {
        font-size: 60px;
        text-align: center;
        text-decoration: none;
    }

    #finalPreto {
        width: 100%;
        padding: 8rem 0;
        background-color: #180236;
    }

    #contentFinal {
        display: flex;
        justify-content: center;
        margin: 0 10%;
        padding-bottom: 100px;
        border-bottom: solid 1px #4d4d4d;
    }

    .titleFinal {
        font-size: 16px;
        color: white;
        margin-bottom: 1.5rem;
    }

    #About {
        padding: 0 15px;
        font: 16px;
        color: white;
        width: 25%;
        line-height: 27px;
    }

    #Features {
        margin-left: 86px;
        width: 14%;
        color: #999999;
        transition: 0.4s;
    }

    #Features a {
        text-decoration: none;
        color: #999999;
        transition: 0.3s;
    }

    #Features p {
        margin-bottom: 10px;
    }

    #Features a:hover {
        color: white;
    }

    #FollowUs {
        display: flex;
        flex-direction: column;
        width: 15%;
    }

    #iconesFinal svg {
        fill: #999999;
        margin-right: 32px;
        transition: 0.4s;
    }

    #iconesFinal svg:hover {
        fill: white;
    }

    #SN input {
        border-radius: 30px;
        height: 40px;
        background-color: white;
        border: solid 1px #999999;
        vertical-align: middle;
        color: #d12126;
        font-size: 1em;
        font-family: 'Quicksand', sans-serif;
        padding: 10px;
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
        border-right: none;
    }


    a {
        text-decoration: none;
        color: black;
        transition: 0.4s;
    }

    a:hover {
        font-size: 20px;
    }

    .botaocad {
        width: 100%;
        font-size: 25px;
        border-radius: 10px;
        border: none;
        letter-spacing: 3px;
        transition: 0.3s, color 0.3s, font-size 0.3s;
        cursor: pointer;
    }

    .botaocad:hover {
        color: white;
        background-color: green;
        font-size: 27px;
    }

    #centro {
        justify-content: center;
    }

    .textForms {
        text-align: center;
        font-size: 30px;
    }

    #landingpg {
        background-color: white;
        padding: 20px;
        width: 40%;
        margin: 0 auto;
        margin-top: 15%;
        margin-bottom: 20%;
        border-radius: 5px;
        color: black;
        box-shadow: 5px 10px 10px #000006;
        line-height: 25px;
    }

    #telalanding {
        background-image: url("./fundo - Copia.jpg");
        background-attachment: fixed;
        background-blend-mode: multiply;
        background-color: rgba(0%, 0%, 0%, 70%);
        display: flex;
        flex-direction: row;
        justify-content: flex-start;
    }

    #btncad {
        margin-top: 10px;
        height: 35px;
    }

    #sobrenos {
        background-color: white;
        color: black;
        margin-bottom: 15%;
        height: 500px;
        width: 80%;
        border-radius: 10px;
        display: grid;
        grid-template-columns: 2fr 2fr 2fr;
    }

    .img {
        width: 30px;
        z-index: 30;
    }

    #logo {
        color: white;
        text-decoration: none;

    }

    .imglogo {
        width: 12vh;
    }

    #fotopresa {
        position: fixed;
        align-items: end;
        top: 80vh;
        left: 190vh;


    }

    #imglogo {
        box-shadow: 3px 3px 5px rgba(0, 0, 0, 0.2), 7px 7px 10px rgba(0, 0, 0, 0.4);
        border-radius: 50%;
        height: 12vh;
    }

    #centrocabecalho {
        display: flex;
        align-items: center;
        gap: 10vh;
    }

    #logarbtn {
        background-color: transparent;
        border: none;
        color: white;
        cursor: pointer;
        border-radius: 5px;
        transition: 0.3s;
    }

    #logarbtn:hover {
        color: green;
    }

    #cadastrarbtn {
        background-color: transparent;
        border: none;

        color: white;
        cursor: pointer;
        border-radius: 5px;
        transition: 0.3s;
    }

    #cadastrarbtn:hover {
        color: green;
    }

    #Sobrenós{ 
        text-align: center;
        padding:10vh;
    }
    #sobrenostitle{ 
        margin-top: 10vh;
        text-align: center;}
</style>

<body>
    <header id=cabecalho>
        <div>
            <a href="/" id="logo">
                <h1 class=titulo>AxoTech</h1>
            </a>
        </div>
    
    <div id="centrocabecalho">
        <a href="/login"><button id="logarbtn">Logar</button></a>
       <a href="/register"><button id="cadastrarbtn">Cadastrar</button></a>
    </div>
    </header>
    <div id="imagem">

    </div>

    <div id="fotopresa">
        <img id="imglogo" src="./foto2dalogo.jfif" />
    </div>

    <main>
        <?php echo $__env->yieldContent('conteudo'); ?>
    </main>

    <footer>
        <div id="finalPreto">
            <div id="contentFinal">
                <div id="About">
                    <h1 class="titleFinal">Prévia Sobre Nós</h1>
                    <p>Bem-vindo à AxoTech, sua passagem para o futuro tecnológico! Desde a nossa fundação, temos o
                        compromisso de oferecer produtos de ponta e soluções inovadoras para satisfazer suas
                        necessidades tecnológicas.</p>
                </div>
                <div id="Features">
                    <h1 class="titleFinal">Áreas do Site</h1>
                    <div id="itemsFeatures">
                        <p><a href="/">AxoTech</a>
                        </p>
                        <p><a href="">Serviços</a></p>
                        <p><a href="">Lojas
                                Afiliadas</a></p>
                        <p><a href="">Contatos</a></p>
                    </div>
                </div>
                <div id="FollowUs">
                    <h1 class="titleFinal">Nós Procure nas nossas Redes Sociais </h1>
                    <div id="iconesFinal">
                        <svg xmlns="http://www.w3.org/2000/svg" height="1em"
                            viewBox="0 0 448 512"><!--! Font Awesome Free 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. -->
                            <path
                                d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z">
                            </path>
                        </svg>
                        <svg xmlns="http://www.w3.org/2000/svg" height="1em"
                            viewBox="0 0 448 512"><!--! Font Awesome Free 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. -->
                            <path
                                d="M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z">
                            </path>
                        </svg>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </footer>
</body>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
    integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
    crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"
    integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
    crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"
    integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
    crossorigin="anonymous"></script>

</html><?php /**PATH C:\Users\rodri\Herd\pits-\resources\views/layouts/landinglayout.blade.php ENDPATH**/ ?>