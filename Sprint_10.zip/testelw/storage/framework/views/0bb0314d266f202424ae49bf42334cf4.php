<p>Name: <?php echo e($name); ?></p>
<p>Email: <?php echo e($email); ?></p>
<p>Message: <?php echo e($message->body); ?></p><?php /**PATH H:\testelw\resources\views/email/email_template.blade.php ENDPATH**/ ?>