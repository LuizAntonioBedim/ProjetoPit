<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Http\Controllers\Controller;

class EmailController extends Controller
{
    public function create()
    {
        return view('email.email_template');
    }

    public function sendEmail(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required',
            'email' => 'required|email',
            'message' => 'required',

            
        ]);


        $details = [
            'name' => $request->name,
            'email' => $request->email,
            'message' => $request->message
        ];

        try {
            Mail::send('email.email_template', $details, function($message) {
                $message->to('igorgarcia091206@gmail.com')
                        ->subject('Mensagem de Contato');
            });
        } catch (\Exception $e) {
            return back()->withErrors(['email' => 'Error sending email: ' . $e->getMessage()]);
        }

        return back()->with('success', 'Email enviado com sucesso!');
    }
}
