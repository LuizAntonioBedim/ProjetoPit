<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RespostaController extends Controller
{
    
    public function store(Request $request)
    {
        $respostas = $request->all();

        return redirect()->route('respostas.show')->with('respostas', $respostas);
    }

    public function show(Request $request)
    {
        $respostas = session('respostas');
        return view('respostas', compact('respostas'));
    }
}
