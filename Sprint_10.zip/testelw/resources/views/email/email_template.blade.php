<p>Name: {{ $name }}</p>
<p>Email: {{ $email }}</p>
<p>Message: {{ $message }}</p>