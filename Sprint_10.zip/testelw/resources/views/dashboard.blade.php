@extends('layouts.landinglayout')

@section('conteudo')

<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        </h2>
    </x-slot>
    <div class="form-container">
        <h2>Questionário</h2>

        <form action="{{ route('respostas.store') }}" method="POST">
            @csrf 

            <div class="question">
                <label class="question-label">Pergunta 1</label>
                <div class="options">
                    <label class="option"><input type="radio" name="q1" value="resposta1"> Resposta 1</label>
                    <label class="option"><input type="radio" name="q1" value="resposta2"> Resposta 2</label>
                    <label class="option"><input type="radio" name="q1" value="resposta3"> Resposta 3</label>
                </div>
            </div>

            <div class="question">
                <label class="question-label">Pergunta 2</label>
                <div class="options">
                    <label class="option"><input type="radio" name="q2" value="resposta1"> Resposta 1</label>
                    <label class="option"><input type="radio" name="q2" value="resposta2"> Resposta 2</label>
                    <label class="option"><input type="radio" name="q2" value="resposta3"> Resposta 3</label>
                </div>
            </div>

            <div class="question">
                <label class="question-label">Pergunta 3</label>
                <div class="options">
                    <label class="option"><input type="radio" name="q3" value="resposta1"> Resposta 1</label>
                    <label class="option"><input type="radio" name="q3" value="resposta2"> Resposta 2</label>
                    <label class="option"><input type="radio" name="q3" value="resposta3"> Resposta 3</label>
                </div>
            </div>

            <div class="question">
                <label class="question-label">Pergunta 4</label>
                <div class="options">
                    <label class="option"><input type="radio" name="q4" value="resposta1"> Resposta 1</label>
                    <label class="option"><input type="radio" name="q4" value="resposta2"> Resposta 2</label>
                    <label class="option"><input type="radio" name="q4" value="resposta3"> Resposta 3</label>
                </div>
            </div>

            <button class="submit-btn" type="submit">Enviar</button>
        </form>
    </div>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
            </div>
        </div>
    </div>
</x-app-layout>
@endsection

