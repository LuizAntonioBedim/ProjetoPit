<!DOCTYPE html>
<html lang="pt-br">


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content=" initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <title>AxoTech</title>
</head>
<style>
    * {
        box-sizing: border-box;
        margin: 0 auto;
    }


    .body {
        background-image: url('https://www.showmetech.com.br/wp-content/uploads//2022/03/ghb-e1648002870611.jpg');
        background-attachment: fixed;
        background-blend-mode: multiply;
        background-color: rgba(0%, 0%, 0%, 70%);
    }






    #cabecalho {
        background-color: #180236;
        margin-bottom: 15%;
        color: white;
        padding: 1%;


    }


    .titulo {
        font-size: 60px;
        text-align: center;




    }


    #finalPreto {
        width: 100%;
        padding: 8rem 0;
        background-color: #180236;
    }


    #contentFinal {
        display: flex;
        justify-content: center;
        margin: 0 10%;
        padding-bottom: 100px;
        border-bottom: solid 1px #4d4d4d;
    }


    .titleFinal {
        font-size: 16px;
        color: white;
        margin-bottom: 1.5rem;
    }


    #About {
        padding: 0 15px;
        font: 16px;
        color: white;
        width: 25%;
        line-height: 27px;
    }


    #Features {
        margin-left: 86px;
        width: 14%;
        color: #999999;
        transition: 0.4s;
    }


    #Features a {
        text-decoration: none;
        color: #999999;
        transition: 0.3s;
    }


    #Features p {
        margin-bottom: 10px;
    }


    #Features a:hover {
        color: white;
    }


    #FollowUs {
        display: flex;
        flex-direction: column;
        width: 15%;
    }


    #iconesFinal svg {
        fill: #999999;
        margin-right: 32px;
        transition: 0.4s;
    }


    #iconesFinal svg:hover {
        fill: white;
    }


    #SN input {
        border-radius: 30px;
        height: 40px;
        background-color: white;
        border: solid 1px #999999;
        vertical-align: middle;
        color: #d12126;
        font-size: 1em;
        font-family: 'Quicksand', sans-serif;
        padding: 10px;
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
        border-right: none;
    }


    #SN button {
        position: absolute;
        height: 40px;
        width: 3.2%;
        border: none;
        background-color: #f5f5f7;
        color: black;
        font-size: 1em;
        font-family: 'Quicksand', sans-serif;
        border-top-right-radius: 30px;
        border-bottom-right-radius: 30px;
        transition: 0.4s;
    }


    #SN button:hover {
        background-color: black;
        color: white;
    }


    a {
        text-decoration: none;
        color: black;
        transition: 0.4s;
    }


    a:hover {
        font-size: 20px;
    }


    #cadformulario {
        display: block;
        align-self: center;
        align-items: center;
        background-color: #180236;
        color: white;
        padding: 10%;
        margin-bottom: 25%;


    }


    .registroForm {
        color: white;


    }


    form {
        background-color: white;
        /* fundo roxo */
        padding: 20px;
        width: 20%;
        /* largura do formulário */
        margin: 0 auto;
        /* centralizar o formulário */
        margin-bottom: 15%;
        border-radius: 4%;
        color: black;
        box-shadow: 5px 10px 10px #000006;
    }


    .textocad {
        color: white;
    }


    input[type="submit"] {
        background-color: #fff;
        /* botão branco */
        color: #333;
        /* texto do botão */
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        cursor: pointer;
        outline: none;
    }


    label {
        display: block;
        margin-bottom: 10px;
    }


    input[type="text"],
    input[type="email"],
    input[type="password"] {
        width: 100%;
        height: 40px;
        margin-bottom: 20px;
        padding: 10px;
        border: 1px solid black;
        border-radius: 5px;
        outline: none;


    }


    .botaocad {
        width: 100%;
        font-size: 25px;
        border-radius: 10px;
        border: none;
        letter-spacing: 3px;
        transition: 0.3s, color 0.3s, font-size 0.3s;
        cursor: pointer;


    }

    h1{width: 100%;
    text-align: center;}


    .botaocad:hover {
        color: white;
        background-color: green;
        font-size: 27px;
    }


    #telaform {
        display: flex;
        flex-direction: row;
        justify-content: center;
    }




    #centro {
        justify-content: center;
    }


    .textForms {
        text-align: center;
        font-size: 30px;




    }


    #landingpg {
        background-color: white;
        padding: 20px;
        width: 40%;
        margin: 0 auto;
        margin-bottom: 15%;
        border-radius: 5px;
        color: black;
        box-shadow: 5px 10px 10px #000006;
        line-height: 25px;
    }


    #telalanding {
        display: flex;
        flex-direction: row;
        justify-content: center;
    }


    #btncad {
        margin-top: 10px;
        height: 35px;
    }


    .logo{
        text-decoration: none;
        color: white;
    }
</style>


<body>
    <header id=cabecalho>
        <a href="/" class="logo">
            <h1 class=titulo>AxoTech</h1>
        </a>
    </header>


    <div id="imagem">


    </div>


    <main>
        @yield('conteudo')
        @yield('formulario')
    </main>
    <footer>
        <div id="finalPreto">
            <div id="contentFinal">
                <div id="About">
                    <h1 class="titleFinal">About Us</h1>
                    <p>Bem-vindo à AxoTech, sua passagem para o futuro tecnológico! Desde a nossa fundação, temos o compromisso de oferecer produtos de ponta e soluções inovadoras para satisfazer suas necessidades tecnológicas.</p>
                </div>
                <div id="Features">
                    <h1 class="titleFinal">Features</h1>
                    <div id="itemsFeatures">
                        <p><a href="">AxoTech</a>
                        </p>
                        <p><a href="https://64df60d18b14bd0217586732--jolly-crisp-32427f.netlify.app/">Serviços</a></p>
                        <p><a href="https://64df60d18b14bd0217586732--jolly-crisp-32427f.netlify.app/">Lojas
                                Afiliadas</a></p>
                        <p><a href="https://64df60d18b14bd0217586732--jolly-crisp-32427f.netlify.app/">Contatos</a></p>
                    </div>
                </div>
                <div id="FollowUs">
                    <h1 class="titleFinal">Follow Us</h1>
                    <div id="iconesFinal">
                        <svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 320 512"><!--! Font Awesome Free 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. -->
                            <path d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z">
                            </path>
                        </svg>
                        <svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 512 512"><!--! Font Awesome Free 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. -->
                            <path d="M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z">
                            </path>
                        </svg>
                        <svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 448 512"><!--! Font Awesome Free 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. -->
                            <path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z">
                            </path>
                        </svg>
                        <svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 448 512"><!--! Font Awesome Free 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. -->
                            <path d="M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z">
                            </path>
                        </svg>
                    </div>
                </div>
            </div>
        </div>
        </div>


    </footer>


</body>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>


</html>

