@extends('layouts.app')


@section('conteudo')


<body class="body">
    <div id="telalanding">

    @csrf
        <div id="landingpg">
       IREMOS FAZER ALGUMAS SIMPLES PERGUNTAS SOBRE O SEU OBJETIVO AO QUERER UMA MAQUINA
        <a href="/formulario"><button class="botaocad" id="btncad">AVANÇAR</button></a>
        </div>
    </div>
</body>






@endsection



