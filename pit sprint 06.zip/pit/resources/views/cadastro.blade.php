@extends('layouts.app')

@section('conteudo')

<body id="corpo">
  <div id=telaform>
    <h1 class=textocad>Cadastre-se e se torne um<br>membro da nossa comunidade</h1>

    <form action="/store" method="post">
      @csrf
      <label for="nome">Nome:</label>
      <input type="text" id="nome" name="nome"><br><br>
      <label for="email">E-mail:</label>
      <input type="email" id="email" name="email"><br><br>
      <label for="senha">Senha:</label>
      <input type="password" id="senha" name="senha"><br><br>
      <label for="senha">Confirmar Senha:</label>
      <input type="password" id="senha" name="senha"><br><br>
      <button id=botaocad>CADASTRAR</button>
      <a href="/login">ja possui um login?</a>
    </form>

  </div>
</body>



@endsection