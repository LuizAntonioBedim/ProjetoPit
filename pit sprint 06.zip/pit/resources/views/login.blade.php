@extends('layouts.app')

@section('conteudo')

<body class="body">
  <div id=telaform>
    <h1 class=textocad>Já possui cadastro? <br> Efetue o login!</h1>
    <form action="/auth" method="post">
        @csrf
      <label for="email">E-mail:</label>
      <input type="email" id="email" name="email"><br><br>
      <label for="senha">Senha:</label>
      <input type="password" id="senha" name="password"><br><br>
      <a class="botaocad" href="/form"><button>LOGIN</button></a>
    </form>
  </div>

<!-- <div class="login">
    @if($errors->any())
        @foreach($errors->all() as $error)
            <p>{{ $error }}</p>
        @endforeach
    @endif

    <form action="/auth" method="post">
        @csrf
        <p>
            <label for="email">E-mail:</label>
            <input type="text" id="email" name="email" value="{{ old('email') }}">
        </p>
        <p>
            <label for="password">Senha:</label>
            <input type="password" id="password" name="password" value="">
        </p>
        <p>
            <button type="submit">Login</button>
        </p>    
    </form>
</div> -->
</body>


@endsection