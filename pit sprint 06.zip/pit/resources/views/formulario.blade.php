@extends('layouts.app')

@section('formulario')

<div id = centro>
<h1 textForms>Monte seu PC</h1>
</div>



<div id=Formulariopc>
<form action="formulario" method="post">
  @csrf
    <label for="price">Preço inicial :</label>
    <input type="number" id="price" name="price" required>
    <br><br>
    <label for="options">Qual vai ser o uso do computador :</label>
    <br>
    <label for="option1">
      <input id="option1" type="radio" name="options" value="opção1"> Para uso pessoal
    </label>
    <br>
    <label for="option2">
      <input id="option2" type="radio" name="options" value="opção2"> Para trabalho
    </label>
    <br>
    <label for="option3">
      <input id="option3" type="radio" name="options" value="opção3"> Para jogar
    </label>
    <br><br>
    <button type="submit">Enviar</button>
  </form>

    

</div>



@endsection