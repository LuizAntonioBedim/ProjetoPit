<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;

use Illuminate\Http\Request;
use App\Models\Usuario;

class UsuariosController extends Controller
{
  public function index()
  {
    $regs = Usuario::get();
    return view('index')->with('regs', $regs);
  }
  public function create()
  {
    return view('cadastro');
  }
  public function form()
  {
    return view('form');
  }
  public function formulario()
  {
    return view('formulario');
  }
  public function store(Request $req)
  {
    $reg = new Usuario();
    $reg->nome = $req->nome;
    $reg->email = $req->email;
    $reg->senha = $req->senha;
    $reg->save();
    return redirect(('/login'));
  }
  public function login(Request $req)
  {
    return view('login');
  }
  public function auth(Request $req)
  {
    $credentials = array(
      'email' => $req->email,
      'password' => $req->password
    );

    if (Auth::attempt($credentials)) {
      $req->session()->regenerate();
      return redirect('/form');
    }
    return back()->withErrors([
      'email' => "Usuário ou Senha Inválidos!"
    ])->withInput();
  }
}
/* public function logout(Request $req) {
  Auth::logout();
  $req->session()->invalidate();
  $req->session()->regenerateToken();
  return redirect('login');
 

} */
