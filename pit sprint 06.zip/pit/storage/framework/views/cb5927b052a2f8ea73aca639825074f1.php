


<?php $__env->startSection('conteudo'); ?>


<body class="body">
    <div id="telalanding">


        <div id="landingpg">
       IREMOS FAZER ALGUMAS SIMPLES PERGUNTAS SOBRE O SEU OBJETIVO AO QUERER UMA MAQUINA
        <a href="/create"><button class="botaocad" id="btncad">AVANÇAR</button></a>
        </div>
    </div>
</body>






<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.landinglayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\22202765\Documents\PIt\resources\views/form.blade.php ENDPATH**/ ?>