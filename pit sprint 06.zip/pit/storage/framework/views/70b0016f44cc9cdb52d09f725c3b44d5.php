


<?php $__env->startSection('formulario'); ?>
<Div><h1>Olá</h1></Div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\22202765\Documents\Nova pasta (2)\PIt\resources\views/index.blade.php ENDPATH**/ ?>