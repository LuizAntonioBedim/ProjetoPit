

<?php $__env->startSection('conteudo'); ?>

<body class="body">
  <div id=telaform>
    <h1 class=textocad>Já possui cadastro? <br> Efetue o login!</h1>
    <form action="/auth" method="post">
        <?php echo csrf_field(); ?>
      <label for="email">E-mail:</label>
      <input type="email" id="email" name="email"><br><br>
      <label for="senha">Senha:</label>
      <input type="password" id="senha" name="password"><br><br>
      <button class="botaocad">LOGIN</button>
    </form>
  </div>

<!-- <div class="login">
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($error); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <form action="/auth" method="post">
        <?php echo csrf_field(); ?>
        <p>
            <label for="email">E-mail:</label>
            <input type="text" id="email" name="email" value="<?php echo e(old('email')); ?>">
        </p>
        <p>
            <label for="password">Senha:</label>
            <input type="password" id="password" name="password" value="">
        </p>
        <p>
            <button type="submit">Login</button>
        </p>    
    </form>
</div> -->
</body>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\22202765\Documents\PIt\resources\views/login.blade.php ENDPATH**/ ?>