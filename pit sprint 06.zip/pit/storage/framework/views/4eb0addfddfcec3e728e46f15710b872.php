

<?php $__env->startSection('formulario'); ?>

<div id = centro>
<h1 textForms>Monte seu PC</h1>
</div>



<div id=Formulariopc>
<form action="https://www.freecatphotoapp.com/submit-cat-photo">
    <label for="price">Preço:</label>
    <input type="number" id="price" name="price" required>
    <br><br>
    <label for="options">Selecione uma opção:</label>
    <br>
    <label for="option1">
      <input id="option1" type="radio" name="options" value="opção1"> Opção 1
    </label>
    <br>
    <label for="option2">
      <input id="option2" type="radio" name="options" value="opção2"> Opção 2
    </label>
    <br>
    <label for="option3">
      <input id="option3" type="radio" name="options" value="opção3"> Opção 3
    </label>
    <br><br>
    <button type="submit">Enviar</button>
  </form>

    

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\PIt\resources\views/formulario.blade.php ENDPATH**/ ?>