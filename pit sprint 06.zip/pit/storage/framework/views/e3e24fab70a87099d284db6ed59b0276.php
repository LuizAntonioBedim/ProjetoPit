


<?php $__env->startSection('conteudo'); ?>


<body class="body">
    <div id="telalanding">

    <?php echo csrf_field(); ?>
        <div id="landingpg">
       IREMOS FAZER ALGUMAS SIMPLES PERGUNTAS SOBRE O SEU OBJETIVO AO QUERER UMA MAQUINA
        <a href="/formulario"><button class="botaocad" id="btncad">AVANÇAR</button></a>
        </div>
    </div>
</body>






<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\luizb\OneDrive\Documentos\Atividades Exemplo\pit\resources\views/form.blade.php ENDPATH**/ ?>