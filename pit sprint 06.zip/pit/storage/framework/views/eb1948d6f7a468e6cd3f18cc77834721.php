

<?php $__env->startSection('formulario'); ?>

<div id = centro>
<h1 textForms>Monte seu PC</h1>
</div>



<div id=Formulariopc>
<form action="formulario" method="post">
  <?php echo csrf_field(); ?>
    <label for="price">Preço:</label>
    <input type="number" id="price" name="price" required>
    <br><br>
    <label for="options">Selecione uma opção:</label>
    <br>
    <label for="option1">
      <input id="option1" type="radio" name="options" value="opção1"> Para uso pessoal
    </label>
    <br>
    <label for="option2">
      <input id="option2" type="radio" name="options" value="opção2"> Para trabalho
    </label>
    <br>
    <label for="option3">
      <input id="option3" type="radio" name="options" value="opção3"> Para jogar
    </label>
    <br><br>
    <button type="submit">Enviar</button>
  </form>

    

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\luizb\OneDrive\Documentos\Atividades Exemplo\pit\resources\views/formulario.blade.php ENDPATH**/ ?>