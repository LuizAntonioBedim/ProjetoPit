

<?php $__env->startSection('conteudo'); ?>

<body class="body">
  <div id=telaform>
    <h1 class=textocad>Já possui cadastro? <br> Efetue o login!</h1>
    <form action="/auth" method="post">
        <?php echo csrf_field(); ?>
      <label for="email">E-mail:</label>
      <input type="email" id="email" name="email"><br><br>
      <label for="senha">Senha:</label>
      <input type="password" id="senha" name="senha"><br><br>
      <button class="botaocad">LOGIN</button>
    </form>
  </div>
</body>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\22202765\Documents\pitEmanuel2\PIt\resources\views/login.blade.php ENDPATH**/ ?>