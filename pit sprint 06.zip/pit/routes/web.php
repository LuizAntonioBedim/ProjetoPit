<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UsuariosController;

Route::get('/', [UsuariosController::class, 'index']);

Route::get('/create', [UsuariosController::class, 'create']);

Route::post('/store', [UsuariosController::class, 'store']);

Route::get('/login', [UsuariosController::class, 'login']);

Route::post('/auth', [UsuariosController::class, 'auth']);

Route::get('/form', [UsuariosController::class, 'form']);

Route::get('/formulario', [UsuariosController::class, 'formulario']);

/* Route::get('/login', [UsuariosController::class, 'login'])->name('login');
Route::post('/auth', [UsuariosController::class, 'auth']);
Route::get('/logout', [UsuariosController::class, 'logout']); */



