@extends('layouts.login')

@section('conteudo1')
    <h1>Contato</h1>
    
    @if (session('success'))
        <p>{{ session('success') }}</p>
    @endif

    @if ($errors->any())
        <div>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('email.send') }}" method="POST" id="formulario">
        @csrf
        <label for="name">Nome:</label>
        <input type="text" id="name" name="name" required><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br>

        <label for="message">Mensagem:</label>
        <textarea id="message" name="message" required></textarea><br>

        <button type="submit">Enviar</button>
    </form>
@endsection
