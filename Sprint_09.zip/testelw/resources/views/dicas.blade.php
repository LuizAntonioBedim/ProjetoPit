<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content=" initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
        integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <title>AxoTech</title>
</head>
<style>
    * {
        box-sizing: border-box;
        margin: 0 auto;

    }

    html {
        scroll-behavior: smooth;
    }

    .bg {
        background-image: "fundo.png";
        background-attachment: fixed;
        background-blend-mode: multiply;
        background-color: rgba(0%, 0%, 0%, 70%);
    }

    #cabecalho {
        background-color: #180236;
        margin-bottom: 15%;
        color: white;
        padding: 1%;
    }

    .titulo {
        font-size: 60px;
        text-align: center;
    }

    #finalPreto {
        width: 100%;
        padding: 8rem 0;
        background-color: #180236;
    }

    #contentFinal {
        display: flex;
        justify-content: center;
        margin: 0 10%;
        padding-bottom: 100px;
        border-bottom: solid 1px #4d4d4d;
    }

    .titleFinal {
        font-size: 16px;
        color: white;
        margin-bottom: 1.5rem;
    }

    #About {
        padding: 0 15px;
        font: 16px;
        color: white;
        width: 25%;
        line-height: 27px;
    }

    #Features {
        margin-left: 86px;
        width: 14%;
        color: #999999;
        transition: 0.4s;
    }

    #Features a {
        text-decoration: none;
        color: #999999;
        transition: 0.3s;
    }

    #Features p {
        margin-bottom: 10px;
    }

    #Features a:hover {
        color: white;
    }

    #FollowUs {
        display: flex;
        flex-direction: column;
        width: 15%;
    }

    #iconesFinal svg {
        fill: #999999;
        margin-right: 32px;
        transition: 0.4s;
    }

    #iconesFinal svg:hover {
        fill: white;
    }

    #SN input {
        border-radius: 30px;
        height: 40px;
        background-color: white;
        border: solid 1px #999999;
        vertical-align: middle;
        color: #d12126;
        font-size: 1em;
        font-family: 'Quicksand', sans-serif;
        padding: 10px;
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
        border-right: none;
    }

    #SN button {
        position: absolute;
        height: 40px;
        width: 3.2%;
        border: none;
        background-color: #f5f5f7;
        color: black;
        font-size: 1em;
        font-family: 'Quicksand', sans-serif;
        border-top-right-radius: 30px;
        border-bottom-right-radius: 30px;
        transition: 0.4s;
    }

    #SN button:hover {
        background-color: black;
        color: white;
    }

    a {
        text-decoration: none;
        color: black;
        transition: 0.4s;
    }

    a:hover {
        font-size: 20px;
    }

    .botaocad {
        width: 100%;
        font-size: 25px;
        border-radius: 10px;
        border: none;
        letter-spacing: 3px;
        transition: 0.3s, color 0.3s, font-size 0.3s;
        cursor: pointer;
    }

    .botaocad:hover {
        color: white;
        background-color: green;
        font-size: 27px;
    }

    #centro {
        justify-content: center;
    }

    .textForms {
        text-align: center;
        font-size: 30px;
    }

    #landingpg {
        background-color: white;
        padding: 20px;
        width: 40%;
        margin: 0 auto;
        margin-bottom: 20%;
        border-radius: 5px;
        color: black;
        box-shadow: 5px 10px 10px #000006;
        line-height: 25px;
    }

    #telalanding {
        display: flex;
        flex-direction: row;
        justify-content: center;
    }

    #btncad {
        margin-top: 10px;
        height: 35px;
    }

    #sobrenos {
        background-color: white;
        color: black;
        margin-bottom: 15%;
        height: 500px;
        width: 80%;
        border-radius: 10px;
        display: grid;
        grid-template-columns: 2fr 2fr 2fr;
    }

    .img {
        width: 30px;
        z-index: 30;
    }

    .logo {
        color: white;
        text-decoration: none;
    }

    #titulo {
        text-align: center;
        margin-bottom: 10vh;
    }

    #cards {
        display: flex;
        gap: 10%;
        margin-bottom: 20vh;

    }

    #card {
        width: 20%;
        background-color: white;
        text-align: center;
        height: 380px;
        border-radius: 30px 0 30px 0;
        border: 10px solid #180236;
    }

    .cardtxt {
        margin-top: 5vh;
        color: black;
        font-size: 20px;
        margin-bottom: 5vh;
        text-align: center;

    }

    #buttonsbm {
        margin-top: 3vh;
        background-color: #180236;
        border: none;
        border-radius: 5px;
        letter-spacing: 2px;
        width: 60%;
        height: 15%;
        cursor: pointer;
        transition: 0.5s;
        color: white;
        scroll-behavior: smooth;
    }

    #buttonsbm:hover {
        background-color: #180236;
        color: white;
        font-size: 20px;
        width: 63%;
        height: 16%;
    }



    #Processador {
        background-color: white;
        border: 6px solid #180236;
        color: black;
        margin: 5vh;
        border-radius: 20px;
        padding: 5vh;
        scroll-behavior: smooth;
        margin-top: 100vh;
        margin-bottom: 60vh;
    }


    #PlacaMae {
        background-color: white;
        border: 6px solid #180236;
        color: black;
        margin: 5vh;
        border-radius: 20px;
        padding: 5vh;
        scroll-behavior: smooth;
        margin-bottom: 60vh;
    }

    #MemoriaRAM {
        background-color: white;
        border: 6px solid #180236;
        color: black;
        margin: 5vh;
        border-radius: 20px;
        padding: 5vh;
        scroll-behavior: smooth;
        margin-bottom: 60vh;
    }

    #PlacaVideo {
        background-color: white;
        border: 6px solid #180236;
        color: black;
        margin: 5vh;
        border-radius: 20px;
        padding: 5vh;
        scroll-behavior: smooth;
        margin-bottom: 60vh;
    }

    #Armazenamento {
        background-color: white;
        border: 6px solid #180236;
        color: black;
        margin: 5vh;
        border-radius: 20px;
        padding: 5vh;
        scroll-behavior: smooth;
        margin-bottom: 60vh;
    }

    #Fonte{ 
        background-color: white;
        border: 6px solid #180236;
        color: black;
        margin: 5vh;
        border-radius: 20px;
        padding: 5vh;
        scroll-behavior: smooth;
        margin-bottom: 30vh;
    }

    @media (min-width: 768px) and (max-width: 1199px) {
        .titulo {
        font-size: 40px;
    }

    #landingpg {
        width: 80%;
    }

    #sobrenos {
        grid-template-columns: 1fr 1fr;
        height: auto;
    }

    #cards {
        flex-direction: column;
        gap: 5%;
    }

    #card {
        width: 80%;
        margin: 0 auto;
    }
    #Processador, #PlacaMae, #MemoriaRAM, #PlacaVideo, #Armazenamento, #Fonte {
        padding: 3vh;
        margin: 2vh;
        margin-bottom: 20vh;
    }

    .botaocad {
        font-size: 20px;
    }

    #Features, #About, #FollowUs {
        width: 100%;
        margin-left: 0;
    }

    #Features a, #Features p {
        font-size: 14px;
    }
    }
</style>

<body>
    <header id=cabecalho>
        <a href="/dicas" class="logo">
            <h1 class=titulo>AxoTech</h1>
        </a>
    </header>

    <main>
        <div id="titulo">
            <h1 class="titulo">Dicas e Orientações na Montagem do Seu Computador</h1>
        </div>

        <div id="cards">
            <div id="card">
                <div class="cardtxt">Processador (CPU)</div>
                <p>A CPU (Unidade Central de Processamento), frequentemente referida como o "cérebro" do computador, é
                    um componente essencial responsável por executar instruções e processar dados</p>
                <a href="#Processador"> <button id="buttonsbm">Saiba Mais!</button></a>
            </div>
            <div id="card">
                <div class="cardtxt"> Placa Mãe (Motherboard)</div>
                <p>A Placa-Mãe, também conhecida como motherboard, é a principal placa de circuito impresso de um
                    computador,ela conecta e permite a comunicação entre os componentes do sistema
                </p>
                <a href="#PlacaMae"> <button id="buttonsbm">Saiba Mais!</button></a>
            </div>
            <div id="card">
                <div class="cardtxt">Memória RAM </div>
                <p>A Memória RAM (Random Access Memory) é um componente crucial em qualquer computador, responsável pelo
                    armazenamento temporário e acesso rápido a dados que o sistema ultiliza</p>
                <a href="#MemoriaRAM"> <button id="buttonsbm">Saiba Mais!</button></a>

            </div>
        </div>

        <div id="cards">
            <div id="card">
                <div class="cardtxt">Armazenamento</div>
                <p>O armazenamento é um componente essencial do computador responsável por salvar e recuperar dados.
                    Existem dois tipos principais de dispositivos de armazenamento: HDDs e SSDs</p>
                    <a href="#Armazenamento"> <button id="buttonsbm">Saiba Mais!</button></a>
            </div>
            <div id="card">
                <div class="cardtxt"> Placa de Vídeo (GPU)</div>
                <p>A Placa De Vídeo (Graphics Processing Unit), é um componente essencial do computador responsável por
                    renderizar imagens e vídeos na tela fazendo cálculos paralelos, melhorando o desempenho visual
                </p>
                <a href="#PlacaVideo"> <button id="buttonsbm">Saiba Mais!</button></a>
            </div>
            <div id="card">
                <div class="cardtxt">Fonte de Alimentação (PSU)</div>
                <p>A Fonte De Alimentação (Power Supply Unit), é um componente essencial do computador que converte a
                    corrente alternada da rede elétrica em corrente contínua para os componentes internos.</p>
                    <a href="#Fonte"> <button id="buttonsbm">Saiba Mais!</button></a>

            </div>
        </div>


    </main>


    <div id="Processador">
        <h4>Processador (CPU)</h4>
        <p>A CPU (Unidade Central de Processamento), frequentemente referida como o "cérebro" do computador, é um
            componente essencial responsável por executar instruções e processar dados. Ela realiza operações
            aritméticas, lógicas, de controle e de entrada/saída, permitindo que o sistema operacional e os aplicativos
            funcionem.</p>
        <p>A performance de um computador é fortemente influenciada pela velocidade e eficiência da CPU. Processadores
            modernos possuem múltiplos núcleos, permitindo a execução de várias tarefas simultaneamente
            (multithreading), o que melhora significativamente o desempenho em aplicações multitarefa e pesadas, como
            jogos, edição de vídeo e simulações científicas.</p>

    </div>

    <div id="PlacaMae">
        <h4>Placa-Mãe (Motherboard)</h4>
        <p>A placa-mãe, também conhecida como motherboard, é a principal placa de circuito impresso de um computador,
            servindo como a espinha dorsal que conecta e permite a comunicação entre todos os componentes do sistema.
            Ela fornece as conexões físicas e elétricas necessárias para que o processador, memória, armazenamento e
            outros dispositivos se comuniquem de maneira eficiente.</p>
        <p>A placa-mãe distribui energia elétrica para os componentes conectados e facilita a comunicação entre eles
            através de barramentos e conectores. O BIOS/UEFI, armazenado na placa-mãe, é o sistema básico de
            entrada/saída que inicializa o hardware e carrega o sistema operacional.</p>

    </div>

    <div id="MemoriaRAM">
        <h4>Memória RAM (Random Access Memory)</h4>
        <p>A memória RAM (Random Access Memory) é um componente crucial em qualquer computador, responsável pelo
            armazenamento temporário e acesso rápido a dados que o sistema e os aplicativos estão utilizando no momento.
            A RAM permite que o processador acesse rapidamente as informações necessárias para executar tarefas,
            proporcionando um desempenho mais eficiente e ágil.</p>

        <p>A RAM armazena temporariamente os dados e instruções que a CPU e outros componentes precisam acessar
            rapidamente. Ao contrário do armazenamento permanente, como HDDs ou SSDs, a RAM é volátil, o que significa
            que ela perde seus dados quando o sistema é desligado. Isso permite que a RAM forneça acesso extremamente
            rápido a dados, essencial para a execução suave de programas e multitarefa.</p>

    </div>

    <div id="PlacaVideo">
        <h4>Placa de vídeo GPU (Graphics Processing Unit)</h4>
        <p>A placa de vídeo, ou GPU (Graphics Processing Unit), é um componente essencial do computador responsável por
            renderizar imagens e vídeos na tela. Ela processa gráficos complexos e realiza cálculos paralelos,
            melhorando o desempenho visual e permitindo uma experiência de jogo mais fluida e tarefas de design gráfico
            e edição de vídeo mais eficientes.</p>
    </div>

    <div id="Armazenamento">
        <h4>Armazenamento</h4>
        <p>O armazenamento é um componente essencial do computador responsável por salvar e recuperar dados. Existem
            dois tipos principais de dispositivos de armazenamento: HDDs (discos rígidos) e SSDs (unidades de estado
            sólido). Eles armazenam o sistema operacional, aplicativos, arquivos pessoais e todos os dados necessários
            para o funcionamento e uso diário do computador.</p>
    </div>

    <div id="Fonte"> 
        <h4>Fonte De Alimentação PSU (Power Supply Unit)</h4>
        <p>A fonte de alimentação, ou PSU (Power Supply Unit), é um componente essencial de um computador que converte a corrente alternada (AC) da rede elétrica em corrente contínua (DC) que os componentes do computador utilizam. Ela fornece energia elétrica estável e suficiente para todos os componentes internos, como a placa-mãe, processador, memória, unidades de armazenamento e placa de vídeo</p>
        <p>A qualidade e capacidade da PSU são cruciais para a estabilidade e longevidade de um sistema de computador. Uma PSU insuficiente pode causar problemas de desempenho, desligamentos inesperados e até danos aos componentes. Escolher uma PSU de boa qualidade e com potência adequada (medida em watts) é essencial para assegurar que todos os componentes recebam energia suficiente e estável.</p>
    </div>




    <footer>
        <div id="finalPreto">
            <div id="contentFinal">
                <div id="About">
                    <h1 class="titleFinal">About Us</h1>
                    <p>Bem-vindo à AxoTech, sua porta para o futuro! Oferecemos produtos e soluções inovadoras para suas necessidades tecnológicas.</p>
                </div>
                <div id="Features">
                    <h1 class="titleFinal">Features</h1>
                    <div id="itemsFeatures">
                        <p><a href="">AxoTech</a>
                        </p>
                        <p><a href="">Serviços</a></p>
                        <p><a href="">Lojas
                                Afiliadas</a></p>
                        <p><a href="">Contatos</a></p>
                        <p><a href="/dicas">Dicas</a></p>
                    </div>
                </div>
                <div id="FollowUs">
                    <h1 class="titleFinal">Follow Us</h1>
                    <div id="iconesFinal">
                        <svg xmlns="http://www.w3.org/2000/svg" height="1em"
                            viewBox="0 0 320 512"><!--! Font Awesome Free 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. -->
                            <path
                                d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z">
                            </path>
                        </svg>
                        <svg xmlns="http://www.w3.org/2000/svg" height="1em"
                            viewBox="0 0 512 512"><!--! Font Awesome Free 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. -->
                            <path
                                d="M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z">
                            </path>
                        </svg>
                        <svg xmlns="http://www.w3.org/2000/svg" height="1em"
                            viewBox="0 0 448 512"><!--! Font Awesome Free 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. -->
                            <path
                                d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z">
                            </path>
                        </svg>
                        <svg xmlns="http://www.w3.org/2000/svg" height="1em"
                            viewBox="0 0 448 512"><!--! Font Awesome Free 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. -->
                            <path
                                d="M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z">
                            </path>
                        </svg>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </footer>
</body>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
    integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
    crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"
    integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
    crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"
    integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
    crossorigin="anonymous"></script>

</html>